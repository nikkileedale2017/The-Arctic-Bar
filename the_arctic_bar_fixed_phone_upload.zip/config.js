window.ARCTIC_CONFIG = {
  businessName: 'The Arctic Bar',
  phones: ['07594 141231','07787 895618'],
  socials: { instagram: '#thearcticbar1', facebook: '@thearcticbar' },
  adminPassword: 'Arctic2026',
  packages: [
    {name:'Bronze', price:250, desc:'1 double tank machine, 12 litres ready mixed slush, max 4 hours, trailer not included'},
    {name:'Silver', price:400, desc:'2 double tank machines, 24 litres ready mixed slush, max 4 hours, trailer not included'},
    {name:'Gold', price:550, desc:'3 double tank machines, 36 litres ready mixed slush, max 4 hours, trailer included'},
    {name:'Platinum', price:700, desc:'4 double tank machines, 48 litres ready mixed slush, max 4 hours, trailer included'},
    {name:'Diamond', price:1000, desc:'4 machines, 48–96 litres ready mixed slush, trailer, seating, pick n mix and 2 bartenders included'},
    {name:'Custom', price:0, poa:true, desc:'Bespoke package to suit your event'}
  ],
  upgrades: [
    {name:'Personalised Cups', price:2, unit:'from £2 per cup'},
    {name:'Novelty Cups', price:2, unit:'from £2 per cup'},
    {name:'DJ', price:150},
    {name:'LED Shorts & Shots', price:45},
    {name:'Pop Up Bar', price:0, poa:true},
    {name:'LED Lighting All Around', price:0, poa:true},
    {name:'Candy Floss Machine', price:95},
    {name:'Popcorn Machine', price:95},
    {name:'Cake Stand Hire', price:0, poa:true},
    {name:'Sweet Cart', price:95},
    {name:'Pick N Mix', price:0, poa:true},
    {name:'Pub Snacks', price:0, poa:true},
    {name:'Variety of Soft Drinks', price:0, poa:true},
    {name:'Canned Cocktails', price:0, poa:true},
    {name:'Extra Bartenders', price:50, unit:'per bartender'},
    {name:'Extra Slush Mix', price:40, unit:'per 6 litre mix'},
    {name:'Happy Hour Sourz', price:50},
    {name:'Test Tube Shots', price:50},
    {name:'Shot Carousel 61 Mini Shots', price:70}
  ]
};
