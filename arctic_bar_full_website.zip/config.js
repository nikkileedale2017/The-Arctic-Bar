const ARCTIC_CONFIG = {
  businessName: 'The Arctic Bar',
  phone1: '07594 141231',
  phone2: '07787 895618',
  instagram: '#thearcticbar1',
  facebook: '@thearcticbar',
  currency: '£',
  packages: [
    { id: 'bronze', name: 'Bronze', price: 250, detail: '1 double tank machine, 12 litres ready mixed slush, maximum 4 hours. Trailer not included.' },
    { id: 'silver', name: 'Silver', price: 400, detail: '2 double tank machines, 24 litres ready mixed slush, maximum 4 hours. Trailer not included.' },
    { id: 'gold', name: 'Gold', price: 550, detail: '3 double tank machines, 36 litres ready mixed slush, maximum 4 hours. Trailer included.' },
    { id: 'platinum', name: 'Platinum', price: 700, detail: '4 double tank machines, 48 litres ready mixed slush, maximum 4 hours. Trailer included.' },
    { id: 'diamond', name: 'Diamond', price: 1000, detail: '4 double tank machines, 48–96 litres ready mixed slush, trailer, seating, pick n mix and 2 bartenders included.' },
    { id: 'custom', name: 'Custom', price: 0, detail: 'Bespoke package. Price on application.' }
  ],
  upgrades: [
    { id: 'personalised-cups', name: 'Personalised Cups', price: 2, unit: 'per cup' },
    { id: 'novelty-cups', name: 'Novelty Cups', price: 2, unit: 'per cup' },
    { id: 'dj', name: 'DJ', price: 150 },
    { id: 'led-shorts-shots', name: 'LED Shorts & Shots', price: 45 },
    { id: 'candy-floss', name: 'Candy Floss Machine', price: 95 },
    { id: 'popcorn', name: 'Popcorn Machine', price: 95 },
    { id: 'sweet-cart', name: 'Sweet Cart', price: 95 },
    { id: 'extra-bartender', name: 'Extra Bartender', price: 50, unit: 'each' },
    { id: 'extra-slush', name: 'Extra Slush Mix', price: 40, unit: 'per 6 litre mix' },
    { id: 'happy-hour-sourz', name: 'Happy Hour Sourz', price: 50 },
    { id: 'test-tube-shots', name: 'Test Tube Shots', price: 50 },
    { id: 'shot-carousel', name: 'Shot Carousel - 61 Mini Shots', price: 70 },
    { id: 'pop-up-bar', name: 'Pop Up Bar', price: 0, poa: true },
    { id: 'led-lighting', name: 'LED Lighting All Around', price: 0, poa: true },
    { id: 'cake-stand', name: 'Cake Stand Hire', price: 0, poa: true },
    { id: 'pick-n-mix', name: 'Pick N Mix', price: 0, poa: true },
    { id: 'pub-snacks', name: 'Pub Snacks', price: 0, poa: true },
    { id: 'soft-drinks', name: 'Variety of Soft Drinks', price: 0, poa: true },
    { id: 'canned-cocktails', name: 'Canned Cocktails', price: 0, poa: true }
  ]
};
