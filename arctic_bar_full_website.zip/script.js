(function(){
  const money = n => `${ARCTIC_CONFIG.currency}${Number(n||0).toFixed(2)}`;
  const getBookings = () => JSON.parse(localStorage.getItem('arcticBookings') || '[]');
  const saveBookings = b => localStorage.setItem('arcticBookings', JSON.stringify(b));

  const packageWrap = document.getElementById('packageOptions');
  const upgradeWrap = document.getElementById('upgradeOptions');
  const summaryLines = document.getElementById('summaryLines');
  const totalPrice = document.getElementById('totalPrice');

  function renderBookingOptions(){
    if(!packageWrap || !upgradeWrap) return;
    packageWrap.innerHTML = ARCTIC_CONFIG.packages.map(p => `<label><input type="radio" name="package" value="${p.id}" data-price="${p.price}" required> <strong>${p.name}</strong><span>${p.detail}</span><br><b>${p.poa ? 'POA' : money(p.price)}</b></label>`).join('');
    upgradeWrap.innerHTML = ARCTIC_CONFIG.upgrades.map(u => `<label><input type="checkbox" name="upgrade" value="${u.id}" data-price="${u.price}"> <b>${u.name}</b><br><span>${u.poa ? 'POA' : money(u.price)} ${u.unit ? u.unit : ''}</span></label>`).join('');
    document.querySelectorAll('input[name="package"],input[name="upgrade"]').forEach(el => el.addEventListener('change', updateSummary));
    updateSummary();
  }

  function updateSummary(){
    if(!summaryLines) return;
    let total = 0, rows = [];
    const selectedPackage = document.querySelector('input[name="package"]:checked');
    if(selectedPackage){
      const pkg = ARCTIC_CONFIG.packages.find(p => p.id === selectedPackage.value);
      total += pkg.price; rows.push([`Package: ${pkg.name}`, pkg.price ? money(pkg.price) : 'POA']);
    }
    document.querySelectorAll('input[name="upgrade"]:checked').forEach(input => {
      const u = ARCTIC_CONFIG.upgrades.find(x => x.id === input.value);
      total += u.price; rows.push([u.name, u.poa ? 'POA' : money(u.price)]);
    });
    summaryLines.innerHTML = rows.length ? rows.map(r => `<div class="summary-line"><span>${r[0]}</span><b>${r[1]}</b></div>`).join('') : '<p>No package selected yet.</p>';
    totalPrice.textContent = money(total);
  }

  const dateInput = document.getElementById('eventDate');
  if(dateInput){
    const today = new Date().toISOString().split('T')[0];
    dateInput.min = today;
    dateInput.addEventListener('change', () => {
      const booked = getBookings().some(b => b.eventDate === dateInput.value);
      if(booked){ alert('This date already has a saved booking. Please choose another date or check the admin page.'); dateInput.value=''; }
    });
  }

  const form = document.getElementById('bookingForm');
  if(form){
    form.addEventListener('submit', e => {
      e.preventDefault();
      const data = Object.fromEntries(new FormData(form).entries());
      if(getBookings().some(b => b.eventDate === data.eventDate)){ document.getElementById('formMessage').textContent = 'That date is already booked.'; return; }
      const pkg = ARCTIC_CONFIG.packages.find(p => p.id === data.package);
      const upgrades = [...document.querySelectorAll('input[name="upgrade"]:checked')].map(x => ARCTIC_CONFIG.upgrades.find(u => u.id === x.value));
      const total = (pkg?.price || 0) + upgrades.reduce((s,u)=>s+(u.price||0),0);
      const booking = {...data, id: Date.now(), packageName: pkg?.name || '', upgrades: upgrades.map(u=>u.name), total, createdAt: new Date().toLocaleString()};
      const bookings = getBookings(); bookings.push(booking); saveBookings(bookings);
      document.getElementById('formMessage').textContent = 'Booking saved. You can print the job sheet from the admin page.';
      form.reset(); updateSummary();
    });
  }

  const list = document.getElementById('bookingsList');
  if(list){
    const bookings = getBookings().sort((a,b)=>(a.eventDate||'').localeCompare(b.eventDate||''));
    list.innerHTML = bookings.length ? bookings.map(b => `<article class="booking-card"><h2>${b.eventDate} - ${b.name}</h2><div class="job-sheet"><p><b>Phone:</b> ${b.phone||''}</p><p><b>Email:</b> ${b.email||''}</p><p><b>Home Address:</b> ${b.address||''}</p><p><b>Venue:</b> ${b.venue||''}</p><p><b>Event Type:</b> ${b.eventType||''}</p><p><b>Start Time:</b> ${b.eventTime||''}</p><p><b>Guests:</b> ${b.guests||''}</p><p><b>Package:</b> ${b.packageName||''}</p><p><b>Upgrades:</b> ${(b.upgrades||[]).join(', ') || 'None'}</p><p><b>Total:</b> ${money(b.total)}</p></div><p><b>Notes:</b> ${b.notes||''}</p><button class="btn ghost" onclick="window.print()">Print Job Sheet</button></article>`).join('') : '<p>No bookings saved yet.</p>';
    const clear = document.getElementById('clearBookings');
    if(clear) clear.addEventListener('click',()=>{ if(confirm('Clear all saved bookings?')){ localStorage.removeItem('arcticBookings'); location.reload(); }});
  }

  renderBookingOptions();
})();
